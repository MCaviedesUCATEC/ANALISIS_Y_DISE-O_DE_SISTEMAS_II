package ar.com.builder.example.components;

public enum Transmission {
    MANUAL,
    AUTOMATIC,
    SEMI_AUTOMATIC
}