package ar.com.builder.example.components;

import ar.com.builder.example.cars.Car;

public class TripComputer {

    private Car car;

    public void setCar(Car car) {
        this.car = car;
    }
}