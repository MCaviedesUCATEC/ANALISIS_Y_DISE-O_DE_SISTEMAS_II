package ar.com.builder.example.components;

public class GPSNavigator {

}