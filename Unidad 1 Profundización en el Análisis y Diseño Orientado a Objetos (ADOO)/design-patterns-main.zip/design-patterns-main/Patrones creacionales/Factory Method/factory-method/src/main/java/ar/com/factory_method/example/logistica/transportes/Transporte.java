package ar.com.factory_method.example.logistica.transportes;

public interface Transporte {
    void transportarCarga();
}
