package ar.com.abstract_factory.example.tienda.muebles;

public interface Mesa {
    void colocarObjetos();
}
