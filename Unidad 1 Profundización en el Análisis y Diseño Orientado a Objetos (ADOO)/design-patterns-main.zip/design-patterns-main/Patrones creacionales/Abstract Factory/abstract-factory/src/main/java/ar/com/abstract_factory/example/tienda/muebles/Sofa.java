package ar.com.abstract_factory.example.tienda.muebles;

public interface Sofa {
    void recostarse();
}
